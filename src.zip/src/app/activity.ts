export class Activity {
    activityId:number;
    description:string;
    charges:string;
}
