export class Ticketbookingdto {
    ticketBookingId:number;
    activityId:number;
    userId:number;
    dateOfVisiting:string;
	numberOfTickets:number;
}
