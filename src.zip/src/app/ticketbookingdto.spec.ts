import { Ticketbookingdto } from './ticketbookingdto';

describe('Ticketbookingdto', () => {
  it('should create an instance', () => {
    expect(new Ticketbookingdto()).toBeTruthy();
  });
});
