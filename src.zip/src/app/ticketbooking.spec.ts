import { Ticketbooking } from './ticketbooking';

describe('Ticketbooking', () => {
  it('should create an instance', () => {
    expect(new Ticketbooking()).toBeTruthy();
  });
});
