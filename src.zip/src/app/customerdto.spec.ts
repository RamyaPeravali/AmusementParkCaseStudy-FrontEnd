import { Customerdto } from './customerdto';

describe('Customerdto', () => {
  it('should create an instance', () => {
    expect(new Customerdto()).toBeTruthy();
  });
});
