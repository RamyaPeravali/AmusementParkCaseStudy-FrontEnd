export class Customer {
    role:string;
    userId:number;
    username:string;
    password:string;
    mobileNumber:string;
    email:string;
    address:string;
}
