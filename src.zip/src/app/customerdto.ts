export class Customerdto {
    userId:number;
    role:string;
    username:string;
	password:string;
    mobileNumber:number;
    email:string;
	address:string;
}
