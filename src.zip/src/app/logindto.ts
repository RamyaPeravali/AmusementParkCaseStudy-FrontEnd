export class Logindto {
    userId:number;
    password:string;
}
